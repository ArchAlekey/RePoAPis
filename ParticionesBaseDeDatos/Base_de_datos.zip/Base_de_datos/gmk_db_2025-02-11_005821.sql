USE gmk;
DROP TABLE IF EXISTS `cat_marcas`;


CREATE TABLE `cat_marcas` (
  `nid_marca` int NOT NULL AUTO_INCREMENT,
  `cnombre_marca` varchar(50) NOT NULL,
  `ccodigo_marca` varchar(15) NOT NULL,
  `bhabilitado` bit(1) NOT NULL,
  `dfecha_alta` date NOT NULL,
  `dfecha_baja` date DEFAULT NULL,
  PRIMARY KEY (`nid_marca`),
  KEY `nid_xmarca` (`nid_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `cat_marcas` VALUES (1,'Epomaker','e&m',0x01,'2025-02-08',NULL),(2,'Ajazz','#azz',0x01,'2025-02-08',NULL),(3,'Akko','#akk',0x01,'2025-02-08',NULL);

DROP TABLE IF EXISTS `cat_modelos`;
CREATE TABLE `cat_modelos` (
  `nid_modelo` int NOT NULL AUTO_INCREMENT,
  `cnombre_modelo` varchar(50) NOT NULL,
  `ccodigo_modelo` varchar(15) NOT NULL,
  `bhabilitado` bit(1) NOT NULL,
  `dfecha_alta` date NOT NULL,
  `dfecha_baja` date DEFAULT NULL,
  PRIMARY KEY (`nid_modelo`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `cat_modelos` VALUES (1,'TH80','#111',0x01,'2025-02-08',NULL),(2,'GK61','#222',0x01,'2025-02-08',NULL),(3,'GK64','#333',0x01,'2025-02-08',NULL),(4,'GK96S','#444',0x01,'2025-02-08',NULL),(5,'TH40','#555',0x01,'2025-02-08',NULL),(6,'AK33','99&',0x01,'2025-02-08',NULL),(7,'K620T','88&',0x01,'2025-02-08',NULL),(8,'AJ199','77&',0x01,'2025-02-08',NULL),(9,'AK60','66&',0x01,'2025-02-08',NULL),(10,'30688 Plus','$123',0x01,'2025-02-08',NULL),(11,'3061','$456',0x01,'2025-02-08',NULL),(12,'5075S','$789',0x01,'2025-02-08',NULL),(13,'ACR Pro 68','$012',0x01,'2025-02-08',NULL);


DROP TABLE IF EXISTS `tbl_teclados`;

CREATE TABLE `tbl_teclados` (
  `nid_teclado` int NOT NULL AUTO_INCREMENT,
  `nid_marca` int NOT NULL,
  `nid_modelo` int NOT NULL,
  `cdistribucion` varchar(20) NOT NULL,
  `nprecio` double(10,2) NOT NULL,
  `bhabilitado` bit(1) NOT NULL,
  `dfecha_alta` date NOT NULL,
  `dfecha_baja` date DEFAULT NULL,
  PRIMARY KEY (`nid_teclado`),
  KEY `nid_marca` (`nid_marca`),
  KEY `nid_modelo` (`nid_modelo`),
  KEY `nid_xteclado` (`nid_teclado`),
  CONSTRAINT `tbl_teclados_ibfk_1` FOREIGN KEY (`nid_marca`) REFERENCES `cat_marcas` (`nid_marca`),
  CONSTRAINT `tbl_teclados_ibfk_2` FOREIGN KEY (`nid_modelo`) REFERENCES `cat_modelos` (`nid_modelo`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `tbl_teclados` VALUES (1,2,9,'Español',999.99,0x01,'2025-02-08',NULL),(2,2,8,'Ingles',1100.75,0x01,'2025-02-08',NULL),(3,1,2,'Ingles',600.00,0x01,'2025-02-08',NULL),(4,3,10,'Español',850.00,0x01,'2025-02-08',NULL),(5,3,11,'Ingles',1330.80,0x01,'2025-02-08',NULL),(6,1,5,'Ingles',1250.80,0x01,'2025-02-08',NULL),(7,2,6,'Ingles',1500.50,0x01,'2025-02-08',NULL),(8,2,7,'Español',1600.20,0x01,'2025-02-08',NULL),(9,1,1,'Español',980.99,0x01,'2025-02-08',NULL),(10,3,12,'Ingles',1500.00,0x01,'2025-02-08',NULL);

DROP TABLE IF EXISTS `tbl_ventas`;

CREATE TABLE `tbl_ventas` (
  `nid_venta` int NOT NULL AUTO_INCREMENT,
  `nid_marca` int NOT NULL,
  `nid_teclado` int NOT NULL,
  `ncantidad_vendida` int NOT NULL,
  `ntotal_venta` decimal(10,2) NOT NULL,
  `dfecha_transacción` date NOT NULL,
  PRIMARY KEY (`nid_venta`,`nid_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci

INSERT INTO `tbl_ventas` VALUES (3,1,3,7,4200.00,'2025-02-11'),(13,1,6,1,1250.00,'2025-02-11'),(1,2,1,2,1999.98,'2025-02-11'),(2,2,1,6,5999.94,'2025-02-11'),(4,2,2,9,9906.75,'2025-02-11'),(5,2,2,2,2201.50,'2025-02-11'),(6,2,2,1,1100.75,'2025-02-11'),(7,2,2,10,11007.50,'2025-02-11'),(8,2,1,8,7999.92,'2025-02-11'),(9,2,8,5,8001.00,'2025-02-11'),(10,2,8,4,6400.80,'2025-02-11'),(14,2,7,7,10503.50,'2025-02-11'),(11,3,4,4,3400.00,'2025-02-11'),(12,3,5,15,19962.00,'2025-02-11');

